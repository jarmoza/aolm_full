      

The following tasks are yet to be done to achieve those 4 components in [[What will the chapter do]]:

1.  Review all data quality research in notes thus far
2.  Read more on data quality, expanding the scope to more authors and fields
3.  Review the Emily Dickinson data sets that have been aggregated so far and produce a data document accounting for all of them
4.  Review code implemented to produce an amalgam Emily Dicqkinson data set
5.  Finish the code to produce the amalgam Emily Dickinson data set
6.  Review data quality metrics produced thus far and implement the full set that will be used to iteratively assess different formations of Dickinson data sets - original, iterative part-amalgam, and final amalgam
7.  Run several models over the different stage data sets, determining the best matching model for the final amalgam data set
8.  Create a written narrative for the above tasks that will lead into the need for a model quality assessment via Chapter 2

===============================================

**Huck finn plans**
	1) Extract play within in a play
2) Observe how it changes with the text time rate of word frequency as it completes and between editions
3) Readdress outline
DONE - 4) Email Tom about fleshed-out outline document
5) Fine tune extraction