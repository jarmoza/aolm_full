Single source data - this digital version of the data is the one used by multiple studies is necessary for the soundness of field findings
	Otherwise everyone is operating on their own, different digital version of the same reality-based source material
	
	"Cost reduction in avoiding duplication in data collection initially is important, but cost reduction later by avoiding the duplication of the maintenance of the data is usually much larger." - (Frank, "METAMODELS FOR DATA QUALITY DESCRIPTION, 3")