      

I’ll begin with an experiment, and tell you in advance that it’s going to fail. How do I know? you ask. Well, I already tried it. How I got to failure: now that’s what matters. Over the course of a literary experiment, just like any other, tried and true notions will fail.