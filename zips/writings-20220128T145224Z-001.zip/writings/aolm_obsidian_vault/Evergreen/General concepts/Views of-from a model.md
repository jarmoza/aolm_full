      

What are the links between a data subset and its wider context/full dataset?

-   These links will be key transitions between a model built and other possible models built

-   One possibility for these is shared fields
-   But the more salient possibility are fields that share or impart together (in combination) dynamics in the data set

-   So first step would be to detect those dynamics - large and small trends

-   Think basic statistical values (max, min, mode, median, mean)