      

Could I use open linked data on text modeling? In other words, annotate and create a graph model of texts and make intra- and inter-text connections

“federated” data analysis of texts using open linked data