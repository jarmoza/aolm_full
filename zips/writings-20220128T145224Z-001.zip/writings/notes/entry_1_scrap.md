That is something that must be declared from the outset – this new understanding that arose from the ashes of that age.
